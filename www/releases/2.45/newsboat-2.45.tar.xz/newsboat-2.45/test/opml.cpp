#include "opml.h"

#include <libxml/xmlsave.h>

#include "3rd-party/catch.hpp"
#include "cache.h"
#include "fileurlreader.h"
#include "rssfeed.h"
#include "test_helpers/envvar.h"
#include "test_helpers/misc.h"
#include "test_helpers/tempfile.h"

using namespace newsboat;

TEST_CASE("opml::generate creates an XML document with feed URLs in OPML format",
	"[Opml]")
{
	const auto check =
		[]
		(const FeedContainer& feedcontainer, bool version2)
	-> std::string {
		xmlDocPtr opml = opml::generate(feedcontainer, version2);

		xmlBufferPtr buffer = xmlBufferCreate();

		xmlSaveCtxtPtr context = xmlSaveToBuffer(buffer, nullptr, 0);
		xmlSaveDoc(context, opml);
		xmlSaveClose(context);

		xmlFreeDoc(opml);

		const std::string opmlText(
			reinterpret_cast<const char*>(xmlBufferContent(buffer)),
			xmlBufferLength(buffer));

		xmlBufferFree(buffer);
		buffer = nullptr;

		return opmlText;
	};

	SECTION("No feeds") {
		FeedContainer feeds;

		const std::string expectedOpmlText(
			"<?xml version=\"1.0\"?>\n"
			"<opml version=\"2.0\">"
			"<head><title>Newsboat - Exported Feeds</title></head>"
			"<body/></opml>\n");

		REQUIRE(check(feeds, true) == expectedOpmlText);
	}

	SECTION("A few feeds") {
		ConfigContainer cfg;
		auto rsscache = Cache::in_memory(cfg);
		FeedContainer feeds;

		std::shared_ptr<RssFeed> feed =
			std::make_shared<RssFeed>(rsscache.get(), "https://example.com/feed1.xml");
		feed->set_title("Feed 1");
		feed->set_link("https://example.com/feed1/");
		feeds.add_feed(std::move(feed));

		feed = std::make_shared<RssFeed>(rsscache.get(), "https://example.com/feed2.xml");
		feed->set_title("Feed 2");
		feed->set_link("https://example.com/feed2/");
		feed->set_tags({"tag", "tag,with,commas", "tag/with/slashes", "tag with spaces"});
		feeds.add_feed(std::move(feed));

		const std::string expectedOpml1Text(
			"<?xml version=\"1.0\"?>\n"
			"<opml version=\"1.0\">"
			"<head><title>Newsboat - Exported Feeds</title></head>"
			"<body>"
			"<outline type=\"rss\" "
			"xmlUrl=\"https://example.com/feed1.xml\" "
			"htmlUrl=\"https://example.com/feed1/\" "
			"title=\"Feed 1\" "
			"text=\"Feed 1\"/>"
			"<outline type=\"rss\" "
			"xmlUrl=\"https://example.com/feed2.xml\" "
			"htmlUrl=\"https://example.com/feed2/\" "
			"title=\"Feed 2\" "
			"text=\"Feed 2\"/>"
			"</body>"
			"</opml>\n");

		const std::string expectedOpml2Text(
			"<?xml version=\"1.0\"?>\n"
			"<opml version=\"2.0\">"
			"<head><title>Newsboat - Exported Feeds</title></head>"
			"<body>"
			"<outline type=\"rss\" "
			"xmlUrl=\"https://example.com/feed1.xml\" "
			"htmlUrl=\"https://example.com/feed1/\" "
			"title=\"Feed 1\" "
			"text=\"Feed 1\" "
			"category=\"\"/>"
			"<outline type=\"rss\" "
			"xmlUrl=\"https://example.com/feed2.xml\" "
			"htmlUrl=\"https://example.com/feed2/\" "
			"title=\"Feed 2\" "
			"text=\"Feed 2\" "
			"category=\"tag,tag_with_commas,tag/with/slashes,tag with spaces\"/>"
			"</body>"
			"</opml>\n");

		REQUIRE(check(feeds, false) == expectedOpml1Text);
		REQUIRE(check(feeds, true) == expectedOpml2Text);
	}
}

TEST_CASE("import() populates UrlReader with URLs from the OPML file", "[Opml]")
{
	test_helpers::TempFile urlsFile;

	test_helpers::copy_file("data/test-urls.txt"_path,
		urlsFile.get_path());

	using URL = std::string;
	using Tag = std::string;
	using Tags = std::vector<Tag>;
	const std::map<URL, Tags> testUrls {
		{"http://test1.url.cc/feed.xml", {"~title", "tag1", "tag2"}},
		{"http://anotherfeed.com/", {}},
		{"http://onemorefeed.at/feed/", {"tag1", "~another title", "tag3"}}
	};

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	REQUIRE(urlcfg.get_urls().size() == testUrls.size());

	for (const auto& feed_url : urlcfg.get_urls()) {
		INFO("url = " << feed_url.url);

		const auto entry = testUrls.find(feed_url.url);
		REQUIRE(entry != testUrls.cend());

		const auto& tags = urlcfg.get_entry(feed_url.url)->tags;
		REQUIRE(tags == entry->second);
	}

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/example.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	const std::map<URL, Tags> opmlUrls {
		{"https://example.com/feed.xml", {"~example.com website"}},
		{"https://example.com/mirrors/distrowatch.rss", {"~Distrowatch mirror"}},
		{"https://example.com/feed.atom", {"~example.com website (Atom feed)"}},
		{"https://example.com/feed.rss09", {"~example.com website (RSS 0.9 feed)"}},
		{"https://blogs.example.com/~john/posts.rss", {"~John's musings", "Blogs"}},
		{"https://blogs.example.com/~mike/.rss", {"~Notes by Mike", "Blogs/friends"}},
		{"https://fred.example.com/writing/index.php?type=rss", {"~Fred on everything", "eloquent"}},
	};

	std::map<URL, Tags> combinedUrls;
	combinedUrls.insert(testUrls.cbegin(), testUrls.cend());
	combinedUrls.insert(opmlUrls.cbegin(), opmlUrls.cend());

	urlcfg.reload();
	REQUIRE(urlcfg.get_urls().size() == combinedUrls.size());

	for (const auto& feed_url : urlcfg.get_urls()) {
		INFO("url = " << feed_url.url);

		const auto entry = combinedUrls.find(feed_url.url);
		REQUIRE(entry != testUrls.cend());

		const auto& tags = urlcfg.get_entry(feed_url.url)->tags;
		REQUIRE(tags == entry->second);
	}
}

TEST_CASE("import() skips URLs that start with a pipe symbol (\"|\") "
	"for security instead of turning them into `exec:` URLs",
	"[Opml]")
{
	test_helpers::TempFile urlsFile;

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/piped.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	using URL = std::string;
	using Tag = std::string;
	using Tags = std::vector<Tag>;
	// The Liferea-style pipe URL ("|~/fetch_tweets.py") is dropped so
	// that importing a shared OPML file cannot inject an `exec:` URL
	// that runs arbitrary commands on feed refresh. Only the regular
	// feed URL is imported.
	const std::map<URL, Tags> opmlUrls {
		{"https://example.com/feed.atom", {"~example.com website (Atom feed)", "tagged"}},
	};

	urlcfg.reload();
	REQUIRE(urlcfg.get_urls().size() == opmlUrls.size());

	for (const auto& feed_url : urlcfg.get_urls()) {
		INFO("url = " << feed_url.url);

		const auto entry = opmlUrls.find(feed_url.url);
		REQUIRE(entry != opmlUrls.cend());

		const auto& tags = urlcfg.get_entry(feed_url.url)->tags;
		REQUIRE(tags == entry->second);
	}
}

TEST_CASE("import() ignores the \"filtercmd\" attribute for security and "
	"keeps the URL as a regular feed",
	"[Opml]")
{
	test_helpers::TempFile urlsFile;

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/filtered.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	using URL = std::string;
	using Tag = std::string;
	using Tags = std::vector<Tag>;
	// The "filtercmd" attribute is dropped so that importing a shared
	// OPML file cannot inject a `filter:` URL that runs arbitrary
	// commands on feed refresh. The outline's own xmlUrl is still
	// imported as a regular feed subscription.
	const std::map<URL, Tags> opmlUrls {
		{"https://example.com/another_feed.atom", {"~example.com website (Atom feed)", "misc"}},
		{"https://example.com/firehose", {"~Firehose"}},
	};

	urlcfg.reload();
	REQUIRE(urlcfg.get_urls().size() == opmlUrls.size());

	for (const auto& feed_url : urlcfg.get_urls()) {
		INFO("url = " << feed_url.url);

		const auto entry = opmlUrls.find(feed_url.url);
		REQUIRE(entry != opmlUrls.cend());

		const auto& tags = urlcfg.get_entry(feed_url.url)->tags;
		REQUIRE(tags == entry->second);
	}
}

TEST_CASE("import() skips URLs that are already present in UrlReader",
	"[Opml]")
{
	test_helpers::TempFile urlsFile;

	test_helpers::copy_file("data/test-urls.txt"_path,
		urlsFile.get_path());

	using URL = std::string;
	using Tag = std::string;
	using Tags = std::vector<Tag>;
	const std::map<URL, Tags> testUrls {
		{"http://test1.url.cc/feed.xml", {"~title", "tag1", "tag2"}},
		{"http://anotherfeed.com/", {}},
		{"http://onemorefeed.at/feed/", {"tag1", "~another title", "tag3"}}
	};

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	REQUIRE(urlcfg.get_urls().size() == testUrls.size());

	for (const auto& feed_url : urlcfg.get_urls()) {
		INFO("url = " << feed_url.url);

		const auto entry = testUrls.find(feed_url.url);
		REQUIRE(entry != testUrls.cend());

		const auto& tags = urlcfg.get_entry(feed_url.url)->tags;
		REQUIRE(tags == entry->second);
	}

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/test-urls+.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	const std::map<URL, Tags> opmlUrls {
		{"https://example.com/another_feed.atom", {"~example.com website (Atom feed)"}},
	};

	std::map<URL, Tags> combinedUrls;
	combinedUrls.insert(testUrls.cbegin(), testUrls.cend());
	combinedUrls.insert(opmlUrls.cbegin(), opmlUrls.cend());

	urlcfg.reload();
	REQUIRE(urlcfg.get_urls().size() == combinedUrls.size());

	for (const auto& feed_url : urlcfg.get_urls()) {
		INFO("url = " << feed_url.url);

		const auto entry = combinedUrls.find(feed_url.url);
		REQUIRE(entry != testUrls.cend());

		const auto& tags = urlcfg.get_entry(feed_url.url)->tags;
		REQUIRE(tags == entry->second);
	}
}

TEST_CASE("import() tags from category attribute", "[Opml]")
{
	test_helpers::TempFile urlsFile;
	FileUrlReader urlcfg(urlsFile.get_path());
	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/category.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	const std::vector<std::string> tags{"tag one", "tag_two", "tag/three"};
	urlcfg.reload();
	const auto& urls = urlcfg.get_urls();
	REQUIRE(urls.size() == 1);
	REQUIRE(urlcfg.get_entry(urls[0].url)->tags == tags);
}

TEST_CASE("import() returns an error when the <opml> root element is missing", "[Opml]")
{
	// we want to check the original English error message, not a localized one
	test_helpers::LcCtypeEnvVar lc_ctype;
	lc_ctype.set("C");

	FileUrlReader urlcfg;
	const auto error_message = opml::import(
			"file:/"_path // `Filepath` will append an extra slash
			.join(utils::getcwd())
			.join("data/opml-element-missing.opml"_path),
			urlcfg);

	REQUIRE(error_message.has_value());
	REQUIRE(error_message.value() == "the <opml> root element is missing");
}

TEST_CASE("import() returns an error when the <body> element is missing", "[Opml]")
{
	// we want to check the original English error message, not a localized one
	test_helpers::LcCtypeEnvVar lc_ctype;
	lc_ctype.set("C");

	FileUrlReader urlcfg;
	const auto error_message = opml::import(
			"file:/"_path // `Filepath` will append an extra slash
			.join(utils::getcwd())
			.join("data/body-element-missing.opml"_path),
			urlcfg);

	REQUIRE(error_message.has_value());
	REQUIRE(error_message.value() ==
		"the <body> element in the <opml> root element is missing");
}

TEST_CASE("import() skips verbatim exec: URLs", "[Opml]")
{
	test_helpers::TempFile urlsFile;

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/with_verbatim_exec_url.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	urlcfg.reload();
	const auto urls = urlcfg.get_urls();
	REQUIRE(urls.size() == 1);
	REQUIRE(urls[0].url == "https://example.com/feed.atom");
	const std::vector<std::string> expected_feed_tags({ "~Normal feed", "tagged" });
	REQUIRE(urls[0].tags == expected_feed_tags);
	const std::vector<std::string> expected_alltags({ "tagged" });
	REQUIRE(urlcfg.get_alltags() == expected_alltags);
}

TEST_CASE("import() skips verbatim filter: URLs", "[Opml]")
{
	test_helpers::TempFile urlsFile;

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/with_verbatim_filter_url.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	urlcfg.reload();
	const auto urls = urlcfg.get_urls();
	REQUIRE(urls.size() == 1);
	REQUIRE(urls[0].url == "https://example.com/feed.atom");
	const std::vector<std::string> expected_feed_tags({ "~Normal feed", "tagged" });
	REQUIRE(urls[0].tags == expected_feed_tags);
	const std::vector<std::string> expected_alltags({ "tagged" });
	REQUIRE(urlcfg.get_alltags() == expected_alltags);
}

TEST_CASE("import() skips verbatim query: URLs", "[Opml]")
{
	test_helpers::TempFile urlsFile;

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/with_verbatim_query_url.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	urlcfg.reload();
	const auto urls = urlcfg.get_urls();
	REQUIRE(urls.size() == 1);
	REQUIRE(urls[0].url == "https://example.com/feed.atom");
	const std::vector<std::string> expected_feed_tags({ "~Normal feed", "tagged" });
	REQUIRE(urls[0].tags == expected_feed_tags);
	const std::vector<std::string> expected_alltags({ "tagged" });
	REQUIRE(urlcfg.get_alltags() == expected_alltags);
}

TEST_CASE("import() skips URLs with unsupported schemas", "[Opml]")
{
	test_helpers::TempFile urlsFile;

	FileUrlReader urlcfg(urlsFile.get_path());
	urlcfg.reload();

	const auto path =
		"file:/"_path // `Filepath` will append an extra slash
		.join(utils::getcwd())
		.join("data/with_unsupported_schemas.opml"_path);
	REQUIRE_NOTHROW(opml::import(path, urlcfg));

	urlcfg.reload();
	const auto urls = urlcfg.get_urls();
	REQUIRE(urls.size() == 1);
	REQUIRE(urls[0].url == "https://example.com/feed.atom");
	std::vector<std::string> expected_tags({ "~Normal feed" });
	REQUIRE(urls[0].tags == expected_tags);
	REQUIRE(urlcfg.get_alltags().empty());
}

// falls back to "url" if "xmlUrl" is absent

// skips an entry if xmlUrl/url is absent

// in tags, falls back to "title" if "text" is not available

// can exec and filter be nested? OPML:
// <outline
//		type="rss"
//		filtercmd="~/.bin/keep_interesting.pl"
//		xmlUrl="|~/.bin/fetch_tweets.py" />
// For security, OPML import no longer converts pipe-prefixed xmlUrl
// values into `exec:` URLs (the outline above is skipped) and no longer
// honours the `filtercmd` attribute. Users who need these can add the
// equivalent `exec:`/`filter:` entries to their urls file manually.

// ignores <outline> without title/text
