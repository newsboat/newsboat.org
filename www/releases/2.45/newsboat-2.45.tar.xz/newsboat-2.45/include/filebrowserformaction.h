#ifndef NEWSBOAT_FILEBROWSERFORMACTION_H_
#define NEWSBOAT_FILEBROWSERFORMACTION_H_

#include <optional>
#include <sys/stat.h>
#include <grp.h>

#include "configcontainer.h"
#include "file_system.h"
#include "formaction.h"
#include "lineedit.h"
#include "listwidget.h"
#include "stflrichtext.h"

namespace newsboat {

class FileBrowserFormAction : public FormAction {
public:
	enum class Variant {
		FileSelection,
		DirectorySelection,
	};
	FileBrowserFormAction(View&, std::string formstr, ConfigContainer* cfg, Variant variant);
	~FileBrowserFormAction() override = default;
	void prepare() override;
	void init() override;
	std::vector<KeyMapHintEntry> get_keymap_hint() const override;

	void set_default_filename(const Filepath& fn)
	{
		default_filename = fn;
	}

	std::optional<Filepath> get_result()
	{
		return result;
	}

	Dialog id() const override
	{
		switch (variant) {
		case Variant::FileSelection:
			return Dialog::FileBrowser;
		case Variant::DirectorySelection:
			return Dialog::DirBrowser;
		}
		return Dialog::FileBrowser;
	}
	std::string title() override;

	bool handle_event(const Event& event) override;

protected:
	std::string main_widget() const override
	{
		switch (variant) {
		case Variant::FileSelection:
			return "filename";
		case Variant::DirectorySelection:
			return "files";
		}
		return "";
	}

private:
	bool process_operation(Operation op,
		const std::vector<std::string>& args,
		BindingType bindingType = BindingType::BindKey) override;
	void update_title(const Filepath& working_directory);

	void add_file(std::vector<file_system::FileSystemEntry>& id_at_position,
		const Filepath& filename);
	std::vector<file_system::FileSystemEntry> id_at_position;
	std::vector<StflRichText> lines;

	std::string get_formatted_filename(const Filepath& filename, mode_t mode);

	Variant variant;
	std::optional<Filepath> result;

	LineView current_directory;
	LineView file_prompt_line;
	LineEdit filename_input;
	Filepath default_filename;

	ListWidget files_list;

	View& view;
};

} // namespace newsboat

#endif /* NEWSBOAT_FILEBROWSERFORMACTION_H_ */
